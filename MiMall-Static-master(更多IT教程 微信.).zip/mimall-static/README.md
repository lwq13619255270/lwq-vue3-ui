# MiMall-Static

小米电商静态代码，不包含交互部分. 