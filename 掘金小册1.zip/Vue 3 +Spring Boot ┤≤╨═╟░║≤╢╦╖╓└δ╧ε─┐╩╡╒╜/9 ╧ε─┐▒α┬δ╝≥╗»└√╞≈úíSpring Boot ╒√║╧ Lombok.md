## 什么是 Lombok

![](https://p1-jj.byteimg.com/tos-cn-i-t2oaga2asx/gold-user-assets/2020/3/25/17110d38a9ee0da9~tplv-t2oaga2asx-image.image)

>Lombok 项目是一个第三方的 Java 工具库，它会自动插入编辑器和构建工具中，Lombok提供了一组非常有用的注释，用来消除Java类中的大量样板代码，比如 setter getter 方法、构造方法等等，
仅仅在原来的 JavaBean 类上使用 `@Data` 注解就可以替换数百行代码从而使代码变得更加清爽、简洁且易于维护。

大家可以将它理解为一个工具，仅此而已，千万不要觉得它是一个非用不可的框架。

## 为什么要用 Lombok

#### 为什么新蜂商城第一版中没有使用 Lombok

在讲解为什么要使用 Lombok 之前，我先来讲一下在新蜂商城的第一个版本中为什么没有使用 Lombok。

- 非必要

首先是第一个原因，它并不是一个必要的插件。

之前第一个版本的 newbee-mall 项目中，我并没有使用这个工具，随着开源时间的增长，很多人知道了新蜂商城项目，我也因此收到了很多朋友的提醒，让我在项目中使用 Lombok 工具。

但是我觉得，这仅仅是个插件、是个工具而已，它不是 JDK 也不是 MySQL 这种基础组件，也并不是每个开发者都知道它、了解它，所以我并没有把它添加到第一个版本的新蜂商城项目中。

因为这与我对第一版新蜂商城的想法有些不同，第一版我就是要用比较简单、比较少的依赖或者工具来实现这个商城，因为这个商城项目的受众非常广、经验跨度也比较大，所以，我也要考虑到新手、小白、1-3年经验的 Java 学习者和 Java 开发者，我不会选择一些非必要的插件或者框架放到第一版的新蜂商城项目中，让大家都能顺利的运行和使用是第一个版本的新蜂商城所追求的。

- 对小白不友好

这是第二个原因，虽然它仅仅是个工具，但是它多少还是有一些使用成本的。

我对于 Lombok 也比较熟，用了也比较久，所以我知道使用 Lombok 不仅仅是把它整合到项目代码里去，还需要在开发工具中安装它的插件，否则代码里会一片飘红，代码上的红色波浪线会让你有些抓狂，而安装这个插件又有一点麻烦，所以这是我在第一版的新蜂商城项目中没有使用它的第二个原因，对于新手来说 Lombok 是一个不小的麻烦。

- 强迫队友

这是另外一个原因，属于思维拓展了，因为这一点并不是第一版新蜂商城项目不使用 Lombok 的原因。

如果是自己单独写项目的话可能不用在意这个，但是在工作中往往是需要进行团队协作的。在一个开发小组中，其中一个开发者用到了 Lombok，但是其他同事没有使用或者不知情的情况下会造成一些负面影响，Lombok 的使用要求开发者在开发工具中安装对应的插件，如果未安装插件的话，打开一个使用了 Lombok 的项目的话会提示找不到方法等错误。也就是说，如果项目组中有一个人使用了Lombok，那么其他人最好也要安装 Lombok 插件，否则协同开发时会出现一些小问题，我曾经就是在不知情的情况下被强迫过。

![](https://p1-jj.byteimg.com/tos-cn-i-t2oaga2asx/gold-user-assets/2020/3/11/170c8e9e71af0fd4~tplv-t2oaga2asx-image.image)

#### Lombok 的优点

说完了它的小缺点，我们再来看一下为什么 Lombok 这么受欢迎，接下来我用一个简单的例子来让大家认识一下它的优点。

以下是新蜂商城中轮播图 POJO 对象的字段及定义：

```java
    //轮播图 JavaBean
    public class Carousel {
        private Integer carouselId;
        private String carouselUrl;
        private String redirectUrl;
        private Integer carouselRank;
        private Byte isDeleted;
        private Date createTime;
        private Integer createUser;
        private Date updateTime;
        private Integer updateUser;
    }
```

如果想要在项目中使用这个对象，我们就必须还要给每一个字段加上 setter 和 getter 方法，有可能还要写构造方法、equals() 方法、toString() 方法等等，这些方法量多而且没有技术含量，但是我们又不得不去写它们。

此时，Lombok 出现了，这个工具的主要作用是通过一些注解，消除刚刚提到的这种看似无用但是又不得不写的代码，Lombok 的解决方式如下：

```java
    @Data
    public class Carousel {
        private Integer carouselId;
        private String carouselUrl;
        private String redirectUrl;
        private Integer carouselRank;
        private Byte isDeleted;
        private Date createTime;
        private Integer createUser;
        private Date updateTime;
        private Integer updateUser;
    }
```

仅仅加一个 `@Data` 注解即可，接下来我们再来看一下 Carousel 这个 POJO 类的结构：

![](https://p1-jj.byteimg.com/tos-cn-i-t2oaga2asx/gold-user-assets/2020/3/25/171110101ee4cfd4~tplv-t2oaga2asx-image.image)

我们仅仅在类上添加了一个注解，并没有添加 setter/getter 等方法，但是这些方法已经自动生成了，这就是 Lombok 的作用。

Lombok 想要解决的是在我们 POJO 类中大量的 getter/setter、equals()、toString() 等等可能不会用到但是仍然需要在类中定义的方法，在使用 Lombok 之后，将由它来自动帮你实现部分代码的生成工作，将极大减少你的代码量、精简和优化这些 POJO 类。

在这一版的新蜂商城项目中使用 Lombok 的原因总结如下：

- 很多人对此都提了建议，希望我将 Lombok 添加到项目中
- 减少部分冗余代码

既然选择了它，那它肯定也有它的优点，既然用到了它，我就要告诉大家怎样整合 Lombok、怎样在 IDEA 中安装 Lombok 插件，让你们顺利的使用它。所以接下来的两篇文章中我会介绍 Lombok 的整合以及插件安装时需要注意的问题。

## Spring Boot 整合 Lombok

整合 Lombok 还是比较简单的，只需要在 Spring Boot 项目的 pom.xml 依赖文件中添加 Lombok 的依赖即可：

```xml
        <dependency>
            <groupId>org.projectlombok</groupId>
            <artifactId>lombok</artifactId>
            <version>1.18.8</version>
            <scope>provided</scope>
        </dependency>
```

这里我用到的是 1.18.8 版本，你可以根据需求自己修改这个版本号。

定义一个 POJO 并添加 `@Data` 注解：

```java
    @Data
    public class NewBeeMallPOJO {  
     private String title;  
     private int number;
     private Date createTime;
    }
```

之后你就可以在其它类中构造 NewBeeMallPOJO 类以及调用其中的 getter/setter toString() 等方法了。

```java
    NewBeeMallPOJO newBeeMallPOJO = new NewBeeMallPOJO();
    
    newBeeMallPOJO.setNumber(2);
    
    System.out.println(newBeeMallPOJO.toString());
```

`@Data` 注解是一个比较霸道的注解，它不仅能够生成 POJO 类所有属性的 get() 和 set() 方法，此外还提供了equals、canEqual、hashCode、toString 方法。

如果你不想要生成这么多内容，也可以使用其它的注解来实现你的需求：

- @Setter 注解在属性上，为属性提供 setting 方法
- @Getter 注解在属性上，为属性提供 getting 方法
- @Log4j 注解在类上，为类提供一个 属性名为log 的 log4j 日志对象
- @NoArgsConstructor 注解在类上，为类提供一个无参的构造方法
- @AllArgsConstructor 注解在类上，为类提供一个全参的构造方法
- @Builder 被注解的类加个构造者模式
- @Synchronized  加同步锁
- @NonNull 如果给参数加个这个注解 参数为null会抛出空指针异常
- @Value 注解和 @Data 类似，区别在于它会把所有成员变量默认定义为 private final 修饰，并且不会生成set方法。

部分注解我也写了测试 demo，如下所示。

```java
    @AllArgsConstructor
    @ToString
    public class NewBeeMallPOJO3 {
    
        @Getter
        private String title;
        @Getter
        private int number;
        @Getter
        private Date createTime;
    
    }
```

主要是测试全字段构造方法、单独的 toString() 方法以及字段的 getter 方法：

```java
    @Test
    public void testGetterAndToString() {
        NewBeeMallPOJO3 newBeeMallPOJO3 = new NewBeeMallPOJO3("Lombok测试", 3, new Date());

        System.out.println(newBeeMallPOJO3.getTitle());
        System.out.println(newBeeMallPOJO3.getNumber());
        System.out.println(newBeeMallPOJO3.getClass());
        System.out.println(newBeeMallPOJO3.toString());
    }
```

构造者模式模式大家也可以注意一下，添加了 @Builder 注解后就可以使用这种方式来构造类的实例，案例如下：

```java
    @Builder
    public class NewBeeMallPOJO2 {
        private String title;
        private int number;
        private Date createTime;
    }
```

```java
    @Test
    public void testBuilder() {
        NewBeeMallPOJO2.NewBeeMallPOJO2Builder builder = NewBeeMallPOJO2.builder();
        NewBeeMallPOJO2 newBeeMallPOJO2 =
                builder.number(1)
                        .title("Lombok测试")
                        .createTime(new Date())
                        .build();

        System.out.println(newBeeMallPOJO2.toString());
    }
```

```tips
以上所涉及到的源码已经整理好并上传到百度云，地址和提取密码如下：
链接: https://pan.baidu.com/s/1h3VUW2J2HBythGf-AeE9-g 
提取码: vyty
```

## 我对于 Lombok 这个工具的看法

对于类似 Lombok 这种工具的使用，其实也有一些争论，有人觉得很方便推荐大家使用，也有些人会发表一些反对言论，什么破坏封装性啦、影响代码阅读性之类的言论等等，在这里我也说一下我的看法。

1. 这个工具并不是非用不可，之前我也已经谈过，它就是一个工具而已。
2. 使用这个工具确实会给开发者带来一些便利，简化了一些开发内容。
3. 这个工具也有一些缺点，之前也谈过，我并不反对大家用这个工具，但是使用时一定要和队友沟通好。
4. Lombok 只是一个工具而已，千万不要上纲上线。

总结下来，Lombok 有一些缺点，但是我们也不能忽视它的优点，工具就在这里，你爱用就用，不爱用就把相关依赖去掉，然后自己生成 POJO 类的方法即可，反正这些方法的生成也都有快捷键，千万不要上纲上线，我就想问一句话，不用 Lombok，你代码的封装性就有了？你代码的阅读性就能好了？不见得吧。

## 总结

这节课主要介绍了 Lombok 这个插件，从它的优缺点到它的整合，也解释了为什么在第一版本的新蜂商城项目中为什么没有使用 Lombok，至于这个版本使用了 Lombok 也是因为它的方便，现在这个版本的后端代码里有很多都用到了 Lombok 的注解：

![](https://p1-jj.byteimg.com/tos-cn-i-t2oaga2asx/gold-user-assets/2020/3/25/17111761157af504~tplv-t2oaga2asx-image.image)

![](https://p1-jj.byteimg.com/tos-cn-i-t2oaga2asx/gold-user-assets/2020/3/25/1711176fb3804a70~tplv-t2oaga2asx-image.image)

大家在下载源码后也能够看到，接下来的一篇文章我会介绍一下 Lombok 插件安装时需要注意的事情，让大家都能够无困扰的使用 Lombok 这个工具。
