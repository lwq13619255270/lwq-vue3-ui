## Pinia 简介

![](https://p1-jj.byteimg.com/tos-cn-i-t2oaga2asx/gold-user-assets/2020/5/6/171e95bb76868be2~tplv-t2oaga2asx-zoom-in-crop-mark:3024:0:0:0.awebp)

#### 简介

`Pinia` 起始于 2019 年 11 月左右的一次实验，其目的是设计一个拥有组合式 `API` 的 `Vue` 状态管理库。从那时起，我们就倾向于同时支持 `Vue 2` 和 `Vue 3`，并且不强制要求开发者使用组合式 `API`，我们的初心至今没有改变。除了安装和 SSR 两章之外，其余章节中提到的 `API` 均支持 `Vue 2` 和 `Vue 3`。虽然本文档主要是面向 Vue 3 的用户，但在必要时会标注出 `Vue 2` 的内容，因此 `Vue 2` 和 `Vue 3` 的用户都可以阅读本文档。

上述摘自 [Pinia 官方文档](https://pinia.vuejs.org) 简介，如果用我的话说，`Pinia` 就是 `Vuex5`。而 `Vuex` 则是用于管理 `Vue` 应用跨组件共享数据的工具。
> 跨组件数据指的是，在 A、B、C组件都需要用到的数据，比如购物车的数量，在很多页面是需要用到的。

#### Pinia 的优势

技术永远是在进步的，而我们能做的就是跟上时代的脚步。`Vue3` 发布后，提供的组合式 `API`，它能很好的解耦代码，并且实现功能模块的抽离。
而 `Pinia` 则很好的支持了组合式 `API`风格，还有最重要的就是 `Pinia` 提供了更加简洁的 `API`，让开发者在使用时得心应手。

#### Pinia 对比 Vuex 3.x/4.x

> Vuex 3.x 只适配 Vue 2，而 Vuex 4.x 是适配 Vue 3 的。

`Pinia API` 与 `Vuex(<=4)` 也有很多不同，即：

- `mutation` 已被弃用。它们经常被认为是极其冗余的。它们初衷是带来 `devtools` 的集成方案，但这已不再是一个问题了。
- 无需要创建自定义的复杂包装器来支持 `TypeScript`，一切都可标注类型，`API` 的设计方式是尽可能地利用 `TS` 类型推理。
- 无过多的魔法字符串注入，只需要导入函数并调用它们，然后享受自动补全的乐趣就好。
- 无需要动态添加 `Store`，它们默认都是动态的，甚至你可能都不会注意到这点。注意，你仍然可以在任何时候手动使用一个 `Store` 来注册它，但因为它是自动的，所以你不需要担心它。
- 不再有嵌套结构的模块。你仍然可以通过导入和使用另一个 `Store` 来隐含地嵌套 `stores` 空间。虽然 `Pinia` 从设计上提供的是一个扁平的结构，但仍然能够在 Store 之间进行交叉组合。你甚至可以让 `Stores` 有循环依赖关系。
- 不再有可命名的模块。考虑到 `Store` 的扁平架构，`Store` 的命名取决于它们的定义方式，你甚至可以说所有 `Store` 都应该命名。

#### Pinia 如何存储数据

说起这个还真有很多同学对 `Pinia` 的存储概念比较模糊，那么下面我们来分析一下 `Pinia` 和 `localStorage、sessionStorage` 在存储上的区别。

- Pinia
`Pinia` 存储在浏览器内存，它采用的是集中式存储管理应用的所有组件的状态，在不刷新网页的情况下，状态会一直保持，一旦刷新网页，所有状态都将会重制。

- sessionStorage
`sessionStorage` 是一种会话型存储，用于保存同一窗口或标签页的数据，数据保存在浏览器本地，在关闭窗口或标签页之后将会删除这些数据，这就是会话型存储，就跟人于人说话一样，人走了对话就结束了。
- localStorage
`localStorage` 是一种持久性存储，与 `sessionStorage` 的功能近乎相似，但是在数据的存储时长上有所区别。它可以让数据一直存在于浏览器本地，除非你主动的 `clear` 数据，或者重装浏览器。

很多同学会认为既然 `localStorage` 存储时效这么强大，为什么不能用它去代替 `Pinia` 管理应用的数据呢？当然，在某些场景下，数据存在 `localStorage` 是比较合适的，像一些不需要变化的数据。但是在 `Vue` 单页应用开发中，两个组件 `A` 和 `B` 共用一份数据，`B` 若是能响应 `A` 对数据的改动，这种情况下 `localStorage` 和 `sessionStorage` 就显得比较乏力，毕竟 `Pinia` 有一整套高度兼容 `Vue.js` 开发模式的结构。

## Pinia 使用实例

首先我们需要通过 `Vite` 创建一个项目，指令如下：

```bash
yarn create vite
# 或者使用 npm
npm create vite@latest
```

> 根据提示选择 Vue、JavaScript，然后安装 node_modules 包。

然后，引入我们的主角 `pinia`，指令如下：

```bash
yarn add pinia
# 或者使用 npm
npm install pinia
```

**现在假设有一个需求，将初始项目中 `src/components/HelloWorld.vue` 中的 `count` 变量提取成一个全局共享变量。**

#### 开始表演

在 `/src` 目录下新建一个文件夹 `stores`，然后再在文件夹下新建一个文件 `count.js`，用于管理 `count`。代码入下：
```js
import { ref } from 'vue'
import { defineStore } from 'pinia'
export const useCountStore = defineStore('count', () => {
  const count = ref(0) // 初始化一个 count，相当于 Vuex 中的 state 操作
  // 定义一个动作，相当于 Vuex 中的 action，这个函数内可以进行请求操作
  function addCount(value) {
    // value 是外部调用的时候传入的值
    count.value += value // 赋值 count
  }
  // 最后将这两个属性 return 出去，外部调用的时候可以直接获取
  return { count, addCount }
})
```

定义完 `count` 之后，进入 `main.js`，注册一下整个 `store`，如下所示：

```js
// main.js
import { createApp } from 'vue'
import { createPinia } from 'pinia'
import './style.css'
import App from './App.vue'

// 初始化 app 实例
const app = createApp(App)
// 注册 store
app.use(createPinia())
// 挂载实例
app.mount('#app')
```

此时我们在 `src/components` 目录下新建一个 `Son.vue`，代码如下：

```html
<template>
  <div>
    子组件的 count：{{ count }}
  </div>
</template>

<script setup>
// 获取 count.js 中抛出的 useCountStore 方法
import { useCountStore } from '../stores/count'
const { count } = useCountStore() // 通过结构的形式，获取到 count 全局变量
</script>
```

在 `App.vue` 中引入 `Son.vue` 组件，如下所示：

```html
<script setup>
import Son from './components/Son.vue'
</script>

<template>
  <Son />
</template>
```

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/ea848b689570423188ffe1297ab41baa~tplv-k3u1fbpfcp-zoom-1.image)

上图可以看出，`count` 全局变量在 `Son.vue` 中成功渲染。
此时，我希望在 `App.vue` 中添加调用 `addCount` 方法，来实现 `count` 的加法运算。代码如下：

```html
<script setup>
import Son from './components/Son.vue'
import { useCountStore } from './stores/count'
const { addCount } = useCountStore()
const add = () => {
  addCount(2)
}
</script>
<template>
  <Son />
  <button @click="add">加法</button>
</template>
```

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/d26a34ec24644d66be5e069bafb429b6~tplv-k3u1fbpfcp-zoom-1.image)

可以看到，点击“加法”按钮，`Son.vue` 组件中的 `count` 值并没有变化。原因是，从 `useCountStore` 中获取的 `count`，是通过解构获取的，而这种做法，Vue 是无法监测到数据的变化，我们有两种选择，第一种就是直接拿 `store` 进行渲染，所以我们在此修改 `Son.vue` 文件，代码如下：

```html
<template>
  <div>
    子组件的 count：{{ countStore.count }}
  </div>
</template>

<script setup>
import { computed } from 'vue'
// 获取 count.js 中抛出的 useCountStore 方法
import { useCountStore } from '../stores/count'
const countStore = useCountStore()
</script>
```

第二种就是通过 `Pinia` 提供的 `storeToRefs` 方法进行解构，所以我们在此修改 `Son.vue` 文件，代码如下：

```html
<template>
  <div>
    子组件的 count：{{ count }}
  </div>
</template>

<script setup>
import { computed } from 'vue'
// 获取 count.js 中抛出的 useCountStore 方法
import { useCountStore } from '../stores/count'
import { storeToRefs } from 'pinia'
const { count } = storeToRefs(useCountStore())
</script>
```

效果如下图所示。

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/a3b827845a0843178955fc892d194e3f~tplv-k3u1fbpfcp-zoom-1.image)

#### 异步请求

假设在 `useCountStore` 中要修改的 `count` 数据，是需要从某个接口去获取的，那么我们可以在 `addCount` 中进行请求，代码如下：

```js
// stores/count.js
import { ref } from 'vue'
import { defineStore } from 'pinia'
// 模拟一个延迟2秒的请求，返回一个随机数
const ajaxData = () => new Promise((resolve, reject) => {
  setTimeout(() => {
    resolve(Math.random())
  }, 2000)
})
export const useCountStore = defineStore('count', () => {
  const count = ref(0)
  async function addCount() {
    const num = await ajaxData() // 请求一个延迟数据
    count.value += num
  }

  return { count, addCount }
})
```

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/4665fd5e26694504a3d693a3d848abb3~tplv-k3u1fbpfcp-zoom-1.image)

当然，这里 `useCountStore` 中的 `action` 操作，不光是加法，你可以添加一个减法、乘法、除法，凡是涉及到 `count` 变量的操作，都可以在 `useCountStore` 中完成，这样代码就比较工整，在排查问题的时候，只要涉及到 `count` 的问题，你都能在 `useCountStore` 中排查。

## 总结

这一波操作下来，同学们对 `Pinia` 应该有一个大致上的了解。同时也能从实际写法中感受到，相较于 `Vuex` 的 `State、Mutation、Action` 这些繁琐的概念，`Pinia` 确实做得很简便。不过，上述只是让大家有一个大致的了解，想要全方位的了解 `Pinia`，还请认真通读[官方文档](https://pinia.vuejs.org/)，有时候你想要的答案，就在文档里。

[本章节示例代码](https://s.yezgea02.com/1675216752709/vite-project.zip)

> 文档最近更新时间：2023 年 2 月 7 日。