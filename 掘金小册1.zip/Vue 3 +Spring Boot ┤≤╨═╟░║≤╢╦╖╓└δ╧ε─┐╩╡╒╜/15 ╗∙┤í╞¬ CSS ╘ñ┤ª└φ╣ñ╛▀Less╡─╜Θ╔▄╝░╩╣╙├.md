## 前言

![](https://p1-jj.byteimg.com/tos-cn-i-t2oaga2asx/gold-user-assets/2020/5/6/171e94c03ce04e85~tplv-t2oaga2asx-image.image)

本章我们要讲的是 CSS 预处理器，没有学过预处理器的同学，会认识到原来 CSS 也能设置变量、方法。吃透本章内容，对后期上手开发项目写 CSS 部分，有很大的帮助，比如项目的主题色我们可以设置多个变量，不用重复的编写。Flex 布局可以写成一个公用的方法，不必每次都写重复的代码。简单说就是提取大量重复的代码，能让 CSS 更加规范。

## 初识 Less

#### Less 是什么

Less 是一门 CSS 预处理语言，它扩展了 CSS 语言，增加了变量、Mixin、函数等特性，使 CSS 更易维护和扩展。
Less 可以运行在 Node 或浏览器端。最基础的例子如下所示：

```less
@base: #fff;
.wh(@width, @height) {
	width: @width;
  height: @height;
}
.box {
  color: @base;
  .wh('30px', '30px')
}
```

编译输出后的结果：

```less
.box {
	color: #fff;
  width: '30px';
  height: '30px';
}
```

#### 浏览器中使用 Less

我们如何在网页中使用 Less 呢？有两种形式，第一种是通过 npm 下载 Less 包，通过 webpack 打包编译后可以编译成最终的 CSS。第二种是直接通过 Less 脚本在 HTML 页面中使用。
本章为了方便学习 Less 的语法知识，选择第二种形式。首先我们创建一个 Less 文件夹，在文件夹内新建一个 index.html 文件，用命令行的话如下所示：

```bash
mkdir less && cd less && touch index.html
```

用之前介绍的 VSCode 工具打开之后（当然大家也可以选择自己喜欢的编辑器），在 index.html 文件内使用快捷键生产 HTML 基础代码：

![](https://p1-jj.byteimg.com/tos-cn-i-t2oaga2asx/gold-user-assets/2020/5/6/171e94c03da5b31f~tplv-t2oaga2asx-image.image)

> 不得不在此夸一下 VSCode 确实很方便。

随后我们需要去找 Less 的静态资源，在此推荐大家一个好用的静态资源网站，里面有很多前端相关的静态资源— [BootCDN](https://www.bootcdn.cn/)。
最后我们练手的 index.html 代码如下：

```html
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet/less" type="text/css" href="./styles.less" />
  <title>Document</title>
</head>
<body>
  <div class="box">
    <span>我是less</span>
  </div>
  <script src="https://cdn.bootcss.com/less.js/3.11.1/less.min.js"></script>
</body>
</html>
```

styles.less 代码如下：

```less
.box {
  span {
    color: red;
  }
}
```

还记得介绍 VSCode 章节，「Go Live」插件吗？此时便可点击 VSCode 右下角的 「Go Live」，最终网页呈现的效果如下图所示，代表我们成功引入 Less：

![](https://p1-jj.byteimg.com/tos-cn-i-t2oaga2asx/gold-user-assets/2020/5/6/171e94c03e0e1a2c~tplv-t2oaga2asx-image.image)

## Less 的使用

#### Less 中的注释

- 以 `//` 开头的注释，注释单行，且不会被编译到 CSS 文件中。
- 以 `/**/` 包裹的注释，注释多行，同样也不会被编译到 CSS 文件中。

#### Less 中的变量

Less 中使用 `@` 符号申明变量，比如 `@color: red`。比方说我现在写一个电商项目，我需要设置项目中主色、辅助色等，代码如下所示：

```html
// index.html
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet/less" type="text/css" href="./styles.less" />
  <title>Document</title>
</head>
<body>
  <div class="box">
    <p class="one">我是less</p>
    <p class="two">我是less</p>
    <p class="three">我是less</p>
  </div>
  <script src="https://cdn.bootcss.com/less.js/3.11.1/less.min.js"></script>
</body>
</html>
```

```css
// styles.less
@primary: red;
@deepColor: green;
@lightColor: blue;

.box {
  .one {
    color: @primary;
  }
  .two {
    color: @deepColor;
  }
  .three {
    color: @lightColor;
  }
}
```

![](https://p1-jj.byteimg.com/tos-cn-i-t2oaga2asx/gold-user-assets/2020/5/6/171e94c03ed535da~tplv-t2oaga2asx-image.image)

有一点要注意的是，如果在后面声明了同名变量，变量值会被后面的覆盖，比如上述代码：

```less
// styles.less
@primary: red;
@deepColor: green;
@lightColor: blue;
@primary: pink

.box {
  .one {
    color: @primary;
  }
  .two {
    color: @deepColor;
  }
  .three {
    color: @lightColor;
  }
}
```

那么最后第一个 p 标签的文字就会变成粉红色：

![](https://p1-jj.byteimg.com/tos-cn-i-t2oaga2asx/gold-user-assets/2020/5/6/171e94c03f15eb43~tplv-t2oaga2asx-image.image)

> 程序员要培养自己的举一反三能力，颜色可以写成变量，文字的大小同样也可以，并且 less 文件能通过 `@import` 关键词引入其他的 less 文件，后面我会讲到这块内容。

#### Less 中的嵌套

市面上所有 CSS 的预编译器的嵌套规则大同小异，基本嵌套如下：

```less
.a {
  color: #fff;
  .b {
  	width: 20px;
  }
}
```

编译后的代码如下所示：

```css
.a {
	color: #fff;
}
.a .b {
	width: 20px;
}
```

同级场景 `&` 的使用如下所示：

```less
.a {
  color: blue;
  &:hover {
  	color: red;
  }
}
```

> 上述代码 `&` 表示当前节点的 CSS 样式，一般用于处理 CSS 样式的状态 hover、focus、active、link、visited等。

#### Less 中的混合（Mixin）

Less 的混合有三种情况：

- 不带参数；
- 带参数，没有默认值；
- 带参数，且有设置默认值；

调用的时候也存在区别：

- 不带参数：调用时可以不加括号，直接使用；
- 带参数：调用时要加括号，括号里必须要传值，不然编译会报错；
- 带参数且有默认值：调用时要加括号，参数可传可不穿；

下面就用上面的 Demo 页面进行实验，首先是第一种情况，不带参数：

```html
// index.html
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet/less" type="text/css" href="./styles.less" />
  <title>Less</title>
</head>
<body>
  <div class="box">
    <p class="one">我是less</p>
  </div>
  <script src="https://cdn.bootcss.com/less.js/3.11.1/less.min.js"></script>
</body>
</html>
```

样式代码：

```less
.center {
  text-align: center;
}
.red {
  color: red;
}

.box {
  .one {
    .center;
    .red;
  }
}
```

浏览器表现如下：

![](https://p1-jj.byteimg.com/tos-cn-i-t2oaga2asx/gold-user-assets/2020/5/6/171e94c03fea90d8~tplv-t2oaga2asx-image.image)

下面是带参数，且没有默认值的情况：

```less
.center {
  text-align: center;
}
.color(@c) {
  color: @c;
}

.box {
  .one {
    .center;
    .color(green);
  }
}
```

![](https://p1-jj.byteimg.com/tos-cn-i-t2oaga2asx/gold-user-assets/2020/5/6/171e94c0651e6ca5~tplv-t2oaga2asx-image.image)

最后是带默认值的情况：

```less
.center {
  text-align: center;
}
.color(@c: red) {
  color: @c;
}

.box {
  .one {
    .center;
    .color;
  }
}
```

![](https://p1-jj.byteimg.com/tos-cn-i-t2oaga2asx/gold-user-assets/2020/5/6/171e94c03fea90d8~tplv-t2oaga2asx-image.image)

在开发页面时，时常会有需要画三角形的情况，上下左右四个方位的三角形，若是一直复制重复的代码去修改，显得不是那么优雅，这时候我们可以用到匹配模式。
匹配模式下无论同名的哪一个混合被匹配到，都会先执行通用匹配模式的代码， `@_` 表示通用的匹配模式，具体代码如下：

```html
// index.html
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet/less" type="text/css" href="./styles.less" />
  <title>Less</title>
</head>
<body>
  <div class="box">
    <p></p>
  </div>
  <script src="https://cdn.bootcss.com/less.js/3.11.1/less.min.js"></script>
</body>
</html>
```


```less
.triangle(@_, @width, @color) {
  width: 0;
  height: 0;
  border-style: solid;
}
.triangle(Bottom, @width, @color) {
  border-width: @width;
  border-color: @color transparent transparent transparent;
}
.triangle(Left, @width, @color) {
  border-width: @width;
  border-color: transparent @color transparent transparent;
}
.triangle(Top, @width, @color) {
  border-width: @width;
  border-color: transparent transparent @color transparent;
}
.triangle(Right, @width, @color) {
  border-width: @width;
  border-color: transparent transparent transparent @color;
}

.box {
  p {
  	.triangle(Left, 100px, red);
  }
}
```

上述 Less 代码设置了基础的 `.triangle` 样式，再分别设置上下左右四个方位的匹配模式，并且可以通过 `@width` 参数来控制三角形大小，浏览器的展示如下所示：

![](https://p1-jj.byteimg.com/tos-cn-i-t2oaga2asx/gold-user-assets/2020/5/6/171e94c06d2431c3~tplv-t2oaga2asx-image.image)

> 你可以把配置写进共用的样式库中，在需要用到的地方通过 `@import` 关键字引入。

arguments 变量：使用 `@arguments` 表示 mixin 的所有参数，代码示例如下：

```less
.border(@width, @mode, @color) {
	border: @arguments;
}

.one {
	.border(1px, solid, red)
}
```

#### Less 中的运算

算数运算符 +、-、*、/ 可以对任何数字、颜色或者变量进行运算，在 Less 中在加减之前会进行单位的换算。计算的结果以最左侧才作数的单位类型为准。如果单位无效或者失去意义，则单位会被忽略。

```less
width: 20px + 20; // 输出结果为 40px
color: #444 * 2; // 输出结果为 #888888 
```

**calc() 特例**

为了与 CSS 保持兼容， `calc()` 方法并不会对数学表达式进行计算，但是在嵌套函数中会计算变量的数学公式的值。代码如下所示：

```less
@a: 100vh/2
height: calc(50% + (@a - 40px)); // 输出结果为： calc(50% - (50vh - 40px))
```

#### Less 中的转译

转译，简单的理解就是我们原先是什么样的，最终输出的还是什么样。关键字是 `~""`，示例代码如下：

```less
p {
  color: ~"green"; // 编译后的输出结果还是 color: green;
}
```

> 在 Less 3.5+ 版本中，许多以前需要“引号转义”的情况就不再需要了。

#### Less 中的作用域

Less 中的作用域和 CSS 的作用域非常相似，首先 Less 会查询当前作用域内的变量和混合（mixins），如果找不到的话会继续向上一级查询，直到找到为止。示例代码如下：

```less
@var: blur;
body {
  @var: red;
  .one {
    color: @var; // 编译后输出的结果为：color: red;
  }
}
```

#### Less 中的导入

现代前端开发，万物皆是模块。Less 也不例外，我们一个 Less 文件就可以当作一个模块来处理，一个 Less 文件中可以引入另外一个 Less 文件，并且可以使用里面的变量信息，我们来看实例代码：

```html
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet/less" type="text/css" href="./styles.less" />
  <title>Less</title>
</head>
<body>
  <div class="box">
    <p>我是P</p>
  </div>
  <script src="https://cdn.bootcss.com/less.js/3.11.1/less.min.js"></script>
</body>
</html>
```

```less
// styles.less
@import './styles1.less';

@color1: red;

.box {
  p {
    color: @color2;
  }
}
```

```less
// styles1.less
@color2: blue;
```

![](https://p1-jj.byteimg.com/tos-cn-i-t2oaga2asx/gold-user-assets/2020/5/6/171e94c06fb217f0~tplv-t2oaga2asx-image.image)

> 在此建议，声明变量的时候，颜色主题可以单独创建一个 Less 文件。字体大小，文字粗细，阴影的大小，透明度等等也可以单独抽离一个 Less 文件，通过引入的方式全部引入到 index.less 中，在组件中使用的时候，可以只引入 index.less 文件，便可使用在 index.less 中引入的 Less 文件的变量。

## Less 使用实例

#### 文字超出省略

这是前端开发中出现频率比较高的情况，我们来提取混合（Mixin），实例代码如下：

```less
// 单行文字超出显示省略号
.ellipsisSingle {
  -webkit-box-orient: vertical;
	overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
```

我们来编写 index.html 来验证一下：

```html
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet/less" type="text/css" href="./styles.less" />
  <title>Less</title>
</head>
<body>
  <div class="box">
    <div class="text">我是less我是less我是less我是less我是less我是less我是less</div>
  </div>
  <script src="https://cdn.bootcss.com/less.js/3.11.1/less.min.js"></script>
</body>
</html>
```

styles.less：

```less
.ellipsisSingle {
  -webkit-box-orient: vertical;
	overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}


.box {
  .text {
    .ellipsisSingle;
    background: darkgoldenrod;
    width: 200px;
    height: 20px;
  }
}
```

![](https://p1-jj.byteimg.com/tos-cn-i-t2oaga2asx/gold-user-assets/2020/5/6/171e94c07a9cb9cc~tplv-t2oaga2asx-image.image)

就此收手，觉得还是不过瘾。若是需要多行省略的情况呢？下面就用到了带参数的混合（Mixin）：

```less
.ellipsisMultiple(@num: 1) {
  display: -webkit-box;
  -webkit-box-orient: vertical;
	overflow: hidden;
  text-overflow: ellipsis;
  -webkit-line-clamp: @num;
}
```

还是之前的 index.html，styles.less 内容如下：

```less
.box {
  .text {
    .ellipsisMultiple(2);
    background: darkgoldenrod;
    width: 200px;
  }
}
```

![](https://p1-jj.byteimg.com/tos-cn-i-t2oaga2asx/gold-user-assets/2020/5/6/171e94c09ae1c31e~tplv-t2oaga2asx-image.image)

#### 文字垂直居中

很多时候你在写 CSS 样式的时候，会连续写两个连在一起的属性，比如 `height: 20px; line-height: 20px`，目的是为了让标签内的文字垂直居中，写多了就会觉得代码不是那么干净。又到了 Less 出手的时候了，把它封装起来，代码如下：

```less
.line-text-h (@h: 0) {
  height: @h;
  line-height: @h;
}

.box {
  .text {
    .line-text-h(100px);
    background: darkgoldenrod;
    width: 200px;
  }
}
```

浏览器展示效果如下图所示：

![](https://p1-jj.byteimg.com/tos-cn-i-t2oaga2asx/gold-user-assets/2020/5/6/171e94c09b05e184~tplv-t2oaga2asx-image.image)

#### 定位上下左右居中

项目开发中有些场景比如设置空页面的图标上下左右居中，这时我们可以封装一个 Less 混合（Mixin）：

```less
.center {
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
}

.box {
  .text {
    .center;
    background: darkgoldenrod;
    width: 200px;
    height: 200px;
  }
}
```

![](https://p1-jj.byteimg.com/tos-cn-i-t2oaga2asx/gold-user-assets/2020/5/6/171e94c09aa7ddff~tplv-t2oaga2asx-image.image)

#### 三角形绘制

三角形的绘制在开发中也是很常见，特别是上下左右四个方向的三角形，每次编写的时候代码都非常冗余，会有不少重复代码，在此我们可以使用 Less 传入参数的形式，控制三角形的样式和方向：

```html
// index.html
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet/less" type="text/css" href="./styles.less" />
  <title>Less</title>
</head>
<body>
  <div class="box">
    <p></p>
  </div>
  <script src="https://cdn.bootcss.com/less.js/3.11.1/less.min.js"></script>
</body>
</html>
```

```less
.triangle(@_, @width, @color) {
  width: 0;
  height: 0;
  border-style: solid;
}
.triangle(Bottom, @width, @color) {
  border-width: @width;
  border-color: @color transparent transparent transparent;
}
.triangle(Left, @width, @color) {
  border-width: @width;
  border-color: transparent @color transparent transparent;
}
.triangle(Top, @width, @color) {
  border-width: @width;
  border-color: transparent transparent @color transparent;
}
.triangle(Right, @width, @color) {
  border-width: @width;
  border-color: transparent transparent transparent @color;
}

.box {
  p {
  	.triangle(Top, 100px, blue);
  }
}
```

![](https://p1-jj.byteimg.com/tos-cn-i-t2oaga2asx/gold-user-assets/2020/5/6/171e94c0a6a2159b~tplv-t2oaga2asx-image.image)

## 总结

市面上 CSS 预编译器大同小异，语法大抵相同，不同的可能是一些变量符号，学好 Less，切换 Sass 或是 Stylus 都是比较轻松的。

规划好你的 Less 文件，在实际开发项目中能事半功倍，你可以把更多的精力放在业务逻辑上，而不会因为改一个样式问题导致“牵一发动全身”。