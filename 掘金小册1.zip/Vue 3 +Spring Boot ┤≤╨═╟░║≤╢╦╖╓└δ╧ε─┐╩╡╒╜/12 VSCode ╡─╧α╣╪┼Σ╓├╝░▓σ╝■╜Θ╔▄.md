## 前端常用编辑器介绍

![](https://p1-jj.byteimg.com/tos-cn-i-t2oaga2asx/gold-user-assets/2020/5/6/171e91fe26525d80~tplv-t2oaga2asx-image.image)

#### Visual Studio Code

简介：由微软研发，号称是前端现今使用率最高的编辑器，开源项目，并且免费使用。

优点：开源，插件丰富，社区活跃，版本迭代更新频繁。尤其是插件的安装和卸载，可直接在编辑器内操作，十分方便。

#### Sublime Text

简介：它是一个文本编辑器（收费软件，可以无限期试用，但是会有激活提示弹窗），同时也是一个先进的代码编辑器。Sublime Text 是由程序员 Jon Skinner 于 2008 年 1 月份所开发出来，它最初被设计为一个具有丰富扩展功能的 [Vim](https://baike.baidu.com/item/Vim)。

优点：轻量级编辑器，内存占用比较小，很适合打开一些临时查看的文件。

缺点：安装插件比较繁琐，插件社区不活跃。

#### WebStorm

简介：WebStorm 是 [jetbrains](https://baike.baidu.com/item/jetbrains/7502758) 公司旗下一款JavaScript 开发工具。已经被广大中国JS开发者誉为“Web前端开发神器”、“最强大的 HTML5 编辑器”、“最智能的 JavaScript IDE”等。与 IntelliJ IDEA 同源，继承了 IntelliJ IDEA 强大的JS部分的功能。

优点：自动保存，历史记录方便回退，插件、快捷键齐全，集成 Git。可直接使用自带的控制台编译打包代码。

缺点：收费工具，且占用内存高，软件比较大。

#### HBuilder

简介：这是一款国人自己研发的编程软件，[DCloud](https://baike.baidu.com/item/DCloud)（[数字天堂](https://baike.baidu.com/item/%E6%95%B0%E5%AD%97%E5%A4%A9%E5%A0%82/244387)）推出的一款支持[HTML5](https://baike.baidu.com/item/HTML5)的[Web](https://baike.baidu.com/item/Web/150564)开发[IDE](https://baike.baidu.com/item/IDE/8232086)。 [1] HBuilder的编写用到了[Java](https://baike.baidu.com/item/Java/85979)、[C](https://baike.baidu.com/item/C/7252092)、Web和[Ruby](https://baike.baidu.com/item/Ruby/11419)。HBuilder[本身](https://baike.baidu.com/item/%E6%9C%AC%E8%BA%AB/126627)主体是由Java编写。

优点：快，是 HBuilder 的最大优势，通过完整的语法提示和代码输入法、代码块等，大幅提升 HTML、JS、CSS 的开发效率。

缺点：闪退、一些问题官方不能及时处理。

## Visual Studio Code 的安装及插件介绍

#### 安装

去[官网](https://code.visualstudio.com/)直接下载安装包安装便可，注意根据自己的电脑系统去下载对应版本，笔者的系统是 Mac，故下载了如下版本。

![](https://p1-jj.byteimg.com/tos-cn-i-t2oaga2asx/gold-user-assets/2020/5/6/171e91fe26987538~tplv-t2oaga2asx-image.image)

安装完成之后我们便可以使用 VS Code 开发项目。磨刀不误砍柴工，我们需要武装一下 VS Code，下面介绍几个开发时常用的插件。

首先我们打开 VSCode，安装插件的位置如下所示：

![](https://p1-jj.byteimg.com/tos-cn-i-t2oaga2asx/gold-user-assets/2020/5/6/171e91fe26785a1a~tplv-t2oaga2asx-image.image)

> 安装完插件之后，需要重新打开 VS Code ，插件才会生效。

## 实用插件介绍

- Vetur

Vetur 是为 Vue 开发量身打造的插件，当你新建一个空的 Vue 文件，在文件内输入 vue 关键字，能联想一些 vue 文件的快速模板，帮助你快速生成 vue 模板页面，大大提高了开发效率。效果如下所示：

![](https://p1-jj.byteimg.com/tos-cn-i-t2oaga2asx/gold-user-assets/2020/5/6/171e91fe28677e02~tplv-t2oaga2asx-image.image)

- Live Server

以前写静态页面需要实时预览的话，我会使用 [Browsersync](http://www.browsersync.cn/) 在本地启动一个服务，来实现实时保存刷新网页。自从知道 Live Server 插件之后，Browsersync 就被我抛弃了。下面来介绍一下插件使用方法，首先下载 Live Server 安装成功之后重启编辑器。受用方式如下：

![](https://p1-jj.byteimg.com/tos-cn-i-t2oaga2asx/gold-user-assets/2020/5/6/171e91fe2877c866~tplv-t2oaga2asx-image.image)

点击红框内「Go Live」，自动打开默认浏览器，在编辑器内输入内容并保存之后，浏览器会自动刷新页面。这里顺带提一下，VS Code 自带生成 HTML 模板，在空白处输入 「! + TAB」如下图所示：

![](https://p1-jj.byteimg.com/tos-cn-i-t2oaga2asx/gold-user-assets/2020/5/6/171e91fe2aee567b~tplv-t2oaga2asx-image.image)

- carbon-now-sh

这是一个提升逼格的插件，我们在开发的时候难免会遇到一些代码上的问题需要请教领导或同事，如果我们直接复制一大段代码给他们，难免有点不雅，并且有些代码会乱码，所以我们需要这个插件，将代码生成一张图片，使用方法也很简单。

1、选中需要生成图片的代码

2、打开命令行托盘：

```
- Window - `Ctrl + Shift + P`
- Mac - `Cmd + Shift + P`
```

3、输入 “Carbon”，点击它

完成上述步骤之后，会跳转到一个网页，你可以设置图片的颜色以及代码的格式，如下图所示。

![](https://p1-jj.byteimg.com/tos-cn-i-t2oaga2asx/gold-user-assets/2020/5/6/171e91fe5be31504~tplv-t2oaga2asx-image.image)

- Turbo Console Log

开发必备的打印神奇，众所周知前端开发的时候会大量使用 “console.log()” 方法，每次都手敲会十分不便。而这个插件为我们解决了这个难题。使用方法如下：

1、选中变量之后 `Ctrl + Alt + l`

2、删除所有 console.log `Alt + Shift + d`

3、注释所有 conosle.log `Alt + Shift + c`

4、启用所有 console.log `Alt + Shift + u`

![](https://p1-jj.byteimg.com/tos-cn-i-t2oaga2asx/gold-user-assets/2020/5/6/171e91fe6635c269~tplv-t2oaga2asx-image.image)

- open-in-browser

写好页面，打开浏览器是很正常的一步操作，但是就是这么正常的操作，有时候会变得很麻烦。VS Code 没有自带打开默认浏览器的功能，所以我们需要这个插件去弥补这个遗憾。安装完成之后使用方法如下：

![](https://p1-jj.byteimg.com/tos-cn-i-t2oaga2asx/gold-user-assets/2020/5/6/171e91fe9795736f~tplv-t2oaga2asx-image.image)

- Import Cost

每当你引入一个 npm 包，都会在包的后面带上文件的大小，以及打包 gzip 后的文件大小，这样的好处是让你在项目开发过程中引入 npm 包以及自己写的脚本大小，都能做到心里有数，效果如下。

![](https://p1-jj.byteimg.com/tos-cn-i-t2oaga2asx/gold-user-assets/2020/5/6/171e91fe9d0411a4~tplv-t2oaga2asx-image.image)

- Browser Preview

如果你没有双屏，那么开发时就需要来回的切换浏览器和编辑器，这是开发前端页面的痛苦之处。这个插件为我们解决了这个问题，可以在 VS Code 内直接打开浏览器，边编辑代码边预览网页效果。
打开 VS Code 安装 Browser Preview，如下图所示。

![](https://p1-jj.byteimg.com/tos-cn-i-t2oaga2asx/gold-user-assets/2020/5/6/171e91fea2dfd56a~tplv-t2oaga2asx-image.image)

安装成功后，VS Code 左侧栏目会多出一个选项，点击后能在浏览器预览想要的网页，如下图所示。

![](https://p1-jj.byteimg.com/tos-cn-i-t2oaga2asx/gold-user-assets/2020/5/6/171e91fec344ce9c~tplv-t2oaga2asx-image.image)

可以修改打开的浏览器默认地址，快捷键 `ctrl + ,`或者 `command + ,`，打开配置页面，找到扩展下的 Browser Preview ，进行默认地址的修改，如下图所示。

![](https://p1-jj.byteimg.com/tos-cn-i-t2oaga2asx/gold-user-assets/2020/5/6/171e91feca7cf062~tplv-t2oaga2asx-image.image)

## VS Code 内置终端使用

Git 是我们日常使用的代码管理工具，mac 和 window 系统也都有属于自己的 Git 可视化工具，不过既然我们使用了 VS Code ，我们就物尽其用，把它的功能发挥到极致。

打开 VS Code 编辑器，左上角的任务栏有「终端」，如下图所示：

![](https://p1-jj.byteimg.com/tos-cn-i-t2oaga2asx/gold-user-assets/2020/5/6/171e91fece882f60~tplv-t2oaga2asx-image.image)

点击它之后，底部会出来 终端输入框，如下图所示：

![](https://p1-jj.byteimg.com/tos-cn-i-t2oaga2asx/gold-user-assets/2020/5/6/171e91fece9d270d~tplv-t2oaga2asx-image.image)

上图蓝色 “1” 的功能是新增终端输入框，蓝色 ”2“ 是终端分屏，蓝色 “3” 代表删除当前终端输入框。

> 目前市面上多数公司使用的版本管理工具便是 Git，学会如何使用它势在必行。本文不会对 Git 的使用进行详细的讲解，请同学们自行查阅资料。

## VS Code 属性设置

我想设置 VS Code 的字体大小和颜色要去哪里设置呢？首先我们打开 VS Code 点击左上角的 Code —> 首选项—> 设置，如下图所示：

![](https://p1-jj.byteimg.com/tos-cn-i-t2oaga2asx/gold-user-assets/2020/5/6/171e91fedc4e0698~tplv-t2oaga2asx-image.image)

在这里你可以通过常规设置，找到最适合自己的开发方式，这点对程序员来说很重要。找到最舒适的开发模式，对工作效率的提高很有帮助，我个人的习惯是 14 号字体，Tab 两格缩进等等。

## 总结

本章介绍了目前市面上最常用的几款编辑器，以及本课程前端开发使用的 VS Code 编辑器的一些常用插件使用方法。工欲善其事，必先利其器。不要小看了本章介绍的内容，虽没有一劳永逸的事情，但水滴石穿，一点点小的效率提升，在大量的工作量到来的时候，就会得到充分的体现。如果大家有其他的需求，可以去[插件官网](https://marketplace.visualstudio.com/search?target=VSCode&category=Other&sortBy=Installs)搜索自己需要的插件。