仅仅整合是不够的，还需要安装插件，这也是 Lombok 相比较于其它 Java 第三方工具较为反常的地方，像其它工具我们一般在项目中引入其依赖即可直接使用，而 Lombok 会相对有一点小麻烦。

## 未安装 Lombok 插件的情况说明

在前一篇文章中我介绍了 Lombok 的整合和简单的使用 demo，还有一个比较重要的知识点没有讲到，那就是 Lombok 插件的安装，如果 IDEA 上没有安装 Lombok 插件，那么代码会出现如下情况：

- 源码目录出现红色波浪线警告

![](https://p1-jj.byteimg.com/tos-cn-i-t2oaga2asx/gold-user-assets/2020/3/26/17114bac93e31798~tplv-t2oaga2asx-image.image)

- 代码中出现红色波浪线警告

![](https://p1-jj.byteimg.com/tos-cn-i-t2oaga2asx/gold-user-assets/2020/3/26/17114bdca19b4600~tplv-t2oaga2asx-image.image)

更加离奇的一点是虽然项目中一片飘红，但是却能够正常启动和运行，饶是如此，一般人肯定接受不了这种情况，或者说很多人也并不知道这种全是红色警告的项目能够正常启动。在正常的认知里，这种满项目都是红色波浪线的警告的代码一定都不是正确的代码。

试想一下这个场景，有人在开源网站上看到了我们的新蜂商城项目，看完项目介绍和功能演示后觉得非常喜欢，就下载源码到本地学习，这位朋友没有安装 Lombok 插件，那么在经历过成功下载源码、正常导入项目、下载完 Maven 依赖之后，他还是看到了代码中一堆的红色波浪线，此时的他是种什么样的心境呢？

![](https://p1-jj.byteimg.com/tos-cn-i-t2oaga2asx/gold-user-assets/2020/3/26/17114fd91d9003ee~tplv-t2oaga2asx-image.image)

也肯定会有人在心里嘀咕，这个商城作者是坑人的家伙。

前一篇文章中也提到过 Lombok 会误伤队友的情况，我是三年前开始使用 Lombok，使用它的原因并不是因为我了解这个工具，而是因为在开发时被队友误伤，一位同事用了 Lombok 但是没有通知组里的其他开发，导致其他人拉到本地的代码里爆出一堆的红色波浪线。

## Lombok 插件安装

不止用 Lombok 会出现意外，在安装 Lombok 插件到 IDEA 中时可能也会碰到意外，关于这些可能导致你开发不顺利的情况我都有做整理，所以才会在现在这个项目中使用它。
有了解决方式和闭坑技巧，我才能比较放心的给大家用，不然，我直接在项目里用它就是给大家找麻烦，惹得大家都不痛快，接下来就来讲一下 Lombok 插件的安装。

我们可以在 IDEA 的插件市场中直接搜索安装，如下图所示：

![](https://p1-jj.byteimg.com/tos-cn-i-t2oaga2asx/gold-user-assets/2020/3/26/17116436b47d1309~tplv-t2oaga2asx-image.image)

打开设置，点击 `Plugins` 面板，之后在搜索框中输入 `Lombok` 并进行搜索，之后可以看到该插件的搜索结果，点击安装即可，安装成功后需要重启 IDEA，之后再打开就可以看到之前的红色波浪线已经不复存在了。

## 安装失败的原因总结

当然，以上是顺利安装的情况，很简单也很快，但是也有可能遇到不顺利的情况，比如我曾经就碰到过几次，原因无非有两点：

- 插件无法正常下载
- 版本冲突导致安装不成功

这里以我曾经遇到过的案例来讲一下这两种安装失败的情况。

#### 网络问题

在插件市场搜索并且点击安装按钮之后，出现了如下的情形：

![download-lombok](https://p1-jj.byteimg.com/tos-cn-i-t2oaga2asx/gold-user-assets/2020/3/25/171117f49616cbd6~tplv-t2oaga2asx-image.image)

界面始终没有任何反应，在半分钟左右的请求等待后 IDEA 编辑器中直接出现了错误提示弹窗，弹框如下：

![faild-download](https://p1-jj.byteimg.com/tos-cn-i-t2oaga2asx/gold-user-assets/2020/3/25/171117f496a393d6~tplv-t2oaga2asx-image.image)

通过上图可以看到，提示也很清楚，就是无法下载！之后我又把反复的尝试了几次这个安装过程，但是得到的结果都是相同的，之后又尝试了其他的方案，但是都无法正常安装这个插件。

具体原因是与网络有很大的关系，可能是被墙了，或者是刚好那天网络抖动之类的原因，总之无论如何都安装不了这个插件。

#### 版本问题

第二个原因更简单，IDEA 编辑器有不同的版本，Lombok 插件也有不同的版本，如果是下载了不兼容的版本并通过本地安装的方式也无法正常的安装。

## 问题解决

由于无法通过插件仓库下载安装，于是想着通过本地下载并手动安装的方式来把 Lombok 插件安装到 IDEA 编辑器中，过程中也遇到了一些小问题，比如不知道在哪里下载 Lombok 插件的安装包、版本号冲突无法安装等等，这些都已经解决了。

如果你也遇到了网络问题而导致无法正常安装 Lombok 插件，可以尝试一下如下安装过程。

整个过程就是：下载插件包 --> 本地 install 即可。

### 首先找到插件包

Lombok 插件的安装包可以通过两个插件库下载，分别是 IDEA 的官方插件仓库和 GitHub 里 lombok-intellij-plugin 仓库中的 release 包，访问地址分别是：

- http://plugins.jetbrains.com/plugin/6317-lombok-plugin

![](https://p1-jj.byteimg.com/tos-cn-i-t2oaga2asx/gold-user-assets/2020/3/26/171165cc567859fa~tplv-t2oaga2asx-image.image)

- https://github.com/mplushnikov/lombok-intellij-plugin/releases

![](https://p1-jj.byteimg.com/tos-cn-i-t2oaga2asx/gold-user-assets/2020/3/26/171165ef1964b49d~tplv-t2oaga2asx-image.image)

网址打开后可以看到各个版本的 Lombok 插件信息，Lombok 插件的命名中都包含了版本信息，这个版本号也就对应了 IDEA 编辑器的版本，不同版本之间即使安装了也无法正常使用。

### 确认 IDEA 的版本号

打开 IDEA 的安装目录可以看到 IDEA 的版本信息，如图所示：

![](https://p1-jj.byteimg.com/tos-cn-i-t2oaga2asx/gold-user-assets/2020/3/26/171166c3af29f63f~tplv-t2oaga2asx-image.image)

可以看到十三安装的IDEA版本为 `2019.3.1`，因此需要安装对应的 Lombok 插件版本也是 `2019.3`。

当然，Windows 电脑上也可以通过 `Help` -> `About` 来查看 IDEA 的版本信息，Mac 版本的 IDEA 可以通过 `IntelliJ IDEA` -> `About IntelliJ IDEA` 查看 IDEA 的版本信息。

确认好 IDEA 的版本号就可以选择对应版本的 Lombok 插件。

### 下载
    
在前文提到的仓库中找到对应版本的文件，点击下载即可，比如我的版本是 `2019.3.1`，那我就下载 `2019.3` 版本的压缩包文件到本地就可以。

### 本地安装

依次进入 IDEA --> Settings/Preferences --> Plugins

![](https://p1-jj.byteimg.com/tos-cn-i-t2oaga2asx/gold-user-assets/2020/3/26/171167785aab8fb9~tplv-t2oaga2asx-image.image)

在 `Plugins` 面板中有 `install from disk` 按钮，点击后选择下载的 zip 压缩包文件即可，安装成功。

## 总结

在安装完插件并且重启 IDEA之后，不管是项目目录还是代码中都不会再有红色波浪线了：

![](https://p1-jj.byteimg.com/tos-cn-i-t2oaga2asx/gold-user-assets/2020/3/26/17114c06198798d1~tplv-t2oaga2asx-image.image)

![](https://p1-jj.byteimg.com/tos-cn-i-t2oaga2asx/gold-user-assets/2020/3/26/17114c13cf44daa2~tplv-t2oaga2asx-image.image)

也希望大家在运行项目时都能够一切顺利。
