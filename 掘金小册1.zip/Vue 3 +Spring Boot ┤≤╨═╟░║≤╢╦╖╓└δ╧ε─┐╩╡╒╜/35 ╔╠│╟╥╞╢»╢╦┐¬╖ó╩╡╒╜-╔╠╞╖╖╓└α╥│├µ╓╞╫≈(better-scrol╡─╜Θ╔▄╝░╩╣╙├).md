## 前言

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/a0aca6c146b34e50939522e2ec00635e~tplv-k3u1fbpfcp-zoom-in-crop-mark:3024:0:0:0.awebp)

本章节我们将学习到经典的 [better-scroll](https://github.com/ustbhuangyi/better-scroll) 组件，它在 `Github` 上的星星数已经有 16k 之多，受欢迎程度可见一斑,在公司很多项目业务中，也经常会见到它的身影。

丝般柔滑的滚动让用户体验直接上升一个档次，今天我们就来学习如何将其引用到咱们的新蜂商城项目中，让新峰商城的页面也丝滑一下。

## 构建 ListScroll 公用滚动组件

在我们编写滚动组件之前，我们需要在项目中安装 `better-scroll`：

> yarn add better-scroll@2.3.0

接下来我们在 `components` 文件夹下创建 `ListScroll` 组件，将滚动组件以容器的形式抛出，滚动组件内部的内容以 `solt` 插槽的形式展示，接下来编写滚动组件的代码：

```html
<template>
  <div ref="wrapper" class="scroll-wrapper">
    <slot></slot>
  </div>
</template>

<script>
import BScroll from 'better-scroll'
export default {
  props: {
    /**
     * 1 滚动的时候会派发scroll事件，会截流。
     * 2 滚动的时候实时派发scroll事件，不会截流。
     * 3 除了实时派发scroll事件，在swipe的情况下仍然能实时派发scroll事件
     */
    probeType: {
      type: Number,
      default: 1
    },
    // 点击列表是否派发click事件
    click: {
      type: Boolean,
      default: true
    },
    // 是否开启横向滚动
    scrollX: {
      type: Boolean,
      default: false
    },
    // 是否派发滚动事件
    listenScroll: {
      type: Boolean,
      default: false
    },
    // 列表的数据
    scrollData: {
      type: Array,
      default: null
    },
    // 是否派发滚动到底部的事件，用于上拉加载
    pullup: {
      type: Boolean,
      default: false
    },
    // 是否派发顶部下拉的事件，用于下拉刷新
    pulldown: {
      type: Boolean,
      default: false
    },
    // 是否派发列表滚动开始的事件
    beforeScroll: {
      type: Boolean,
      default: false
    },
    // 当数据更新后，刷新scroll的延时
    refreshDelay: {
      type: Number,
      default: 20
    }
  },
  mounted() {
    // 在 DOM 渲染完毕后初始化 better-scroll，大致做一个 20 毫秒的等待，确保 DOM 渲染完毕
    setTimeout(() => {
      this.initScroll()
    }, 20)
  },
  methods: {
    // 初始化滚动组件，拿不到 this.$refs.wrapper 代码不往下走
    initScroll() {
      if (!this.$refs.wrapper) {
        return
      }
      // better-scroll 初始化， 传入配置项参数
      this.scroll = new BScroll(this.$refs.wrapper, {
        probeType: this.probeType,
        click: this.click,
        scrollX: this.scrollX
      })
      // 是否派发滚动事件
      if (this.listenScroll) {
        const self = this
        this.scroll.on('scroll', (position) => {
          self.$emit('scroll', position)
        })
      }
      if (this.pullup) {
        this.scroll.on('scrollEnd', () => {
          // 滚动到底部
          if (this.scroll.y <= (this.scroll.maxScrollY + 50)) {
            // 派发滚动到底部的事件
            this.$emit('scrollToEnd')
          }
        })
      }
      if (this.pulldown) {
        this.scroll.on('touchend', (pos) => {
          // 下拉动作
          if (pos.y > 50) {
            // 下拉刷新
            this.$emit('pulldown')
          }
        })
      }
      if (this.beforeScroll) {
        this.scroll.on('beforeScrollStart', () => {
          // 列表滚动前触发
          this.$emit('beforeScroll')
        })
      }
    },
    disable() {
      // 代理 better-scroll 的 disable 方法
      this.scroll && this.scroll.disable()
    },
    enable() {
        // 代理 better-scroll 的 enable 方法
        this.scroll && this.scroll.enable()
    },
    refresh() {
        // 代理 better-scroll 的 refresh 方法
        this.scroll && this.scroll.refresh()
    },
    scrollTo() {
        // 代理 better-scroll 的 scrollTo 方法
        this.scroll && this.scroll.scrollTo.apply(this.scroll, arguments)
    },
    scrollToElement() {
        // 代理 better-scroll 的 scrollToElement 方法
        this.scroll && this.scroll.scrollToElement.apply(this.scroll, arguments)
    }
  },
  watch: {
    // 监听数据的变化，重新计算高度
    data() {
      setTimeout(() => {
          this.refresh()
      }, this.refreshDelay)
    }
  }
}
</script>

<style lang="less" scoped>
  .scroll-wrapper {
    width: 100%;
    height: 100%;
    overflow: hidden;
  }
</style>
```

同学们浏览这部分代码时，注意一下代码注释，每一行代码都会做一个详细的解释。`Vue3` 也是可以写 `Vue2` 的语法的，由于这个组件年代久远，这边就不对其进行升级了，升级成本过高。

## 如何使用滚动组件 ListScroll

首先我们打开分类页面文件 `src/views/Category.vue`，编写分类列表的头部代码，如下所示：

```html
<template>
  <div class="category-box">
    <header class="category-header wrap">
      <i class="nbicon nbfanhui"></i>
      <div class="header-search">
        <i class="nbicon nbSearch"></i>
        <router-link tag="span" class="search-title" to="./product-list?from=category">全场50元起步</router-link>
      </div>
      <i class="nbicon nbmore"></i>
    </header>
  </div>
</template>

<style lang="less" scoped>
  @import '../common/style/mixin';
  .category-box {
    .category-header {
      background: #fff;
      position: fixed;
      left: 0;
      top: 0;
      .fj();
      .wh(100%, 50px);
      line-height: 50px;
      padding: 0 15px;
      box-sizing: border-box;
      font-size: 15px;
      color: #656771;
      z-index: 10000;
      &.active {
        background: @primary;
      }
      .icon-left {
        font-size: 25px;
        font-weight: bold;
      }
      .header-search {
        display: flex;
        width: 80%;
        height: 20px;
        line-height: 20px;
        margin: 10px 0;
        padding: 5px 0;
        color: #232326;
        background: #F7F7F7;
        border-radius: 20px;
        .nbSearch {
          padding: 0 10px 0 20px;
          font-size: 17px;
        }
        .search-title {
          font-size: 12px;
          color: #666;
        }
      }
    }
  }
</style>
```

浏览器展示效果如下图所示。

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/358cb44e5d234281a66698597fb1cd8b~tplv-k3u1fbpfcp-zoom-1.image)

接下来，我们需要调用分类列表接口，前往 `service` 文件夹新建 `good.js` 文件，添加分类接口并抛出：

```js
// good.js
import axios from '../utils/axios'

export function getCategory() {
  return axios.get('/categories')
}
```
随后我们在 `Category.vue` 中引入接口，并且请求数据：
```html
<script setup>
import { reactive, onMounted } from 'vue'
import { getCategory } from "@/service/good"
const state = reactive({
  categoryData: []
})
onMounted(async () => {
  const { data } = await getCategory()
  state.categoryData = data
})
</script>
```

拿到数据之后，我们看看返回的数据结构，进行下一步分类列表排版规划：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/59fe8ca6724b434db4bdbabd49611668~tplv-k3u1fbpfcp-zoom-in-crop-mark:3024:0:0:0.awebp)

分类接口返回的结构体如上图所示，总共有三级，第一级我们将其放在左边栏，第二级作为对应左边栏的内容，每个第二级对应一个第三级的数组，说起来可能有点绕口，我们用一张图解释一下排版：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/85bd7aa9f475424babeadf00579ba1bd~tplv-k3u1fbpfcp-zoom-in-crop-mark:3024:0:0:0.awebp)

如上图所示，我们来进行页面的排版布局，代码如下：

```html
<template>
  <div class="category-box">
    <header class="category-header wrap">
      <i class="nbicon nbfanhui"></i>
      <div class="header-search">
        <i class="nbicon nbSearch"></i>
        <router-link tag="span" class="search-title" to="./product-list?from=category">全场50元起步</router-link>
      </div>
      <i class="nbicon nbmore"></i>
    </header>
    <div class="search-wrap" ref="searchWrap">
      <list-scroll :scroll-data="state.categoryData" class="nav-side-wrapper">
        <ul class="nav-side">
          <li
            v-for="item in state.categoryData"
            :key="item.categoryId"
            v-text="item.categoryName"
            :class="{'active' : currentIndex == item.categoryId}"
            @click="selectMenu(item.categoryId)"
          ></li>
        </ul>
      </list-scroll>
    </div>
  </div>
</template>
<script setup>
import { reactive, onMounted, ref } from 'vue'
import { getCategory } from "@/service/good"
// composition API 获取 refs 的形式
const searchWrap = ref(null)
const state = reactive({
  categoryData: [],
  currentIndex: 15
})
onMounted(async () => {
  // 这个操作是为了将 searchWrap 这个节点撑满屏幕，否则底部会留白
  let $screenHeight = document.documentElement.clientHeight
  console.log('searchWrap.value', searchWrap.value)
  searchWrap.value.style.height = $screenHeight - 100 + 'px'
  const { data } = await getCategory()
  state.categoryData = data
})
const selectMenu = (index) => {
  state.currentIndex = index
}
</script>
<style lang="less" scoped>
@import '../common/style/mixin';
.search-wrap {
  .fj();
  width: 100%;
  margin-top: 50px;
  background: #F8F8F8;
  .nav-side-wrapper {
    width: 28%;
    height: 100%;
    overflow: hidden;
    .nav-side {
      width: 100%;
      .boxSizing();
      background: #F8F8F8;
      li {
        width: 100%;
        height: 56px;
        text-align: center;
        line-height: 56px;
        font-size: 14px;
        &.active {
          color: @primary;
          background: #fff;
        }
      }
    }
  }
  .search-content {
    width: 72%;
    height: 100%;
    padding: 0 10px;
    background: #fff;
    overflow-y: scroll;
    touch-action: pan-y;
    * {
        touch-action: pan-y;
      }
    .boxSizing();
    .swiper-container {
      width: 100%;
      .swiper-slide {
        width: 100%;
        .category-main-img {
          width: 100%;
        }
        .category-list {
          display: flex;
          flex-wrap: wrap;
          flex-shrink: 0;
          width: 100%;
          .catogory-title {
            width: 100%;
            font-size: 17px;
            font-weight: 500;
            padding: 20px 0;
          }
          .product-item {
            width: 33.3333%;
            margin-bottom: 10px;
            text-align: center;
            font-size: 15px;
            .product-img {
              .wh(30px, 30px);
            }
          }
        }
      }
    }
  }
}
</style>
```

浏览器效果如下图所示。

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/a258044d42f649928f37c990d18979f6~tplv-k3u1fbpfcp-zoom-1.image)

页面左侧的一级分类数据已经渲染完成，接下来就是页面右侧的数据渲染，数据为一级分类下对应的二三级分类数据，代码如下：

```html
<template>
  <div class="category-box">
    ...
    <div class="search-content">
      <list-scroll :scroll-data="state.categoryData" >
        <div class="swiper-container">
          <div class="swiper-wrapper">
            <template v-for="(category, index) in state.categoryData">
              <div class="swiper-slide" v-if="state.currentIndex == category.categoryId" :key="index">
                <!-- <img class="category-main-img" :src="category.mainImgUrl" v-if="category.mainImgUrl"/> -->
                <div class="category-list" v-for="(products, index) in category.secondLevelCategoryVOS" :key="index">
                  <p class="catogory-title">{{products.categoryName}}</p>
                  <div class="product-item" v-for="(product, index) in products.thirdLevelCategoryVOS" :key="index" @click="selectProduct(product)">
                    <img src="//s.weituibao.com/1583591077131/%E5%88%86%E7%B1%BB.png" class="product-img"/>
                    <p v-text="product.categoryName" class="product-title"></p>
                  </div>
                </div>
              </div>
            </template>
          </div>
        </div>
      </list-scroll>
    </div>
  </category-box>
</template>
<script setup>
import { useRouter } from 'vue-router'
const selectProduct = (item) => {
  router.push({ path: 'product-list', query: { categoryId: item.categoryId } })
}
</script>
```

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/b6b253e9aba149cb939b29bc26dc6bd5~tplv-k3u1fbpfcp-zoom-1.image)

丝般柔滑，一触即发，大家可以自行尝试一下。

还有一点需要注意的是，在使用外部公共组件的时候，一定不要忘记注册组件，否则是无法使用的，这种低级错误我们尽量要避免。

## 总结

学完本章，相信同学们对 `better-scroll` 有了一个大致的了解，更深层次的功能，还需要同学们自行挖掘，在此不赘述，学习本就是没有尽头的事情，希望同学们能举一反三。

[本章节示例代码](https://s.yezgea02.com/1675323697653/newbee-mall-h5.zip)

> 文档最近更新时间：2023 年 2 月 7 日。